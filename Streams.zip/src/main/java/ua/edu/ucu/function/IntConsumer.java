package ua.edu.ucu.function;

public interface IntConsumer {
    void accept(int value);
}
